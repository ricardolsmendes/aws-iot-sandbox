def handle(event, context):
    print(event)
    return "Lambda successfully handled the IoT event!"
