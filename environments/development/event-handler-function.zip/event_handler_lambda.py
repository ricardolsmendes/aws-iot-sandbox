def lambda_handler(event, context):
    print(event)
    return "Lambda successfully handled the IoT event!"
